package com.project.questapp.requests;

import lombok.Data;

@Data
public class PostUpdateRequest {

	String title;
	String text;
}
